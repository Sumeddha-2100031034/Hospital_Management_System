package com.example.springboot;

public interface SignUpDAO {
	void insertdata(SignUp sp);
	//SignUp checklogin(String email, String pwd);
}
