package com.example.springboot;

public interface AppointmentDAO {
	void insertDetails(Appointment app);
}
