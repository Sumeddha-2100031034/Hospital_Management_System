package com.example.springboot;

public interface PaymentDAO {
	void insertDetails(Payment p);
}
